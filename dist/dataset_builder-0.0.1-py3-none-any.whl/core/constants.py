CLASS_LIST = [
    "Actinopterygii",
    "Amphibia",
    "Animalia",
    "Arachnida",
    "Aves",
    "Chromista",
    "Fungi",
    "Insecta",
    "Mammalia",
    "Mollusca",
    "Plantae",
    "Protozoa",
    "Reptilia",
]

IGNORE_DIRS = ["species_lists"]