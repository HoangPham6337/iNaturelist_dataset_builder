from setuptools import setup, find_packages

setup(
    name="dataset-builder",
    version="0.0.1",
    author="Hoang Pham",
    author_email="hoangpham4171@gmail.com",
    description="A dataset preparation and visualization toolkit for species classification, targets iNaturelist 2017 dataset.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/HoangPham6337/iNaturelist_dataset_builder",
    packages=find_packages(exclude=["texts*", "scripts*"]),
    include_package_data=True,
    install_requires=[
        "bs4>=0.0.2",
        "matplotlib>=3.3.4",
        "matplotlib-venn>=1.1.2",
        "numpy>=1.19.5",
        "pandas>=1.1.5",
        "Pillow>=8.4.0",
        "pyarrow>=6.0.1",
        "pyyaml>=6.0.1",
        "requests>=2.27.1",
        "scikit-image>=0.17.2",
        "scikit-learn>=0.24.2",
        "scipy>=1.5.4",
        "tqdm>=4.64.1"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6"
)
